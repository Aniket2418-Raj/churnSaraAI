"""
app/main.py — Flask real-time inference API for customer churn prediction.

Run from the project root with:
    python -m app.main
The server listens on http://localhost:8000
"""

import os
import logging
from pathlib import Path

import joblib
from flask import Flask, request, jsonify

from app.utils import customer_json_to_df, predict_churn

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model.pkl"
TRANSFORMER_PATH = BASE_DIR / "transformer.pkl"

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
)
logger = logging.getLogger(__name__)

# ── App + model loading ───────────────────────────────────────────────────────
app = Flask(__name__)

logger.info("Loading model and transformer …")
model = joblib.load(MODEL_PATH)
transformer = joblib.load(TRANSFORMER_PATH)
logger.info("Model and transformer loaded successfully.")


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    """Simple health-check endpoint."""
    return jsonify({"status": "ok"}), 200


@app.route("/predict", methods=["POST"])
def predict():
    """
    Accept a JSON body:
        {"customer": { <feature fields> }}
    Return:
        {"churn_probability": 0.83, "churn_prediction": "Yes"}
    """
    try:
        body = request.get_json(force=True)
        if body is None or "customer" not in body:
            return jsonify({"error": "Request body must contain a 'customer' key."}), 400

        customer_dict = body["customer"]
        customer_df = customer_json_to_df(customer_dict)
        result = predict_churn(customer_df, transformer, model)

        logger.info(
            "Prediction made — probability: %.4f  label: %s",
            result["churn_probability"],
            result["churn_prediction"],
        )
        return jsonify(result), 200

    except ValueError as exc:
        logger.warning("Validation error: %s", exc)
        return jsonify({"error": str(exc)}), 422
    except Exception as exc:  # noqa: BLE001
        logger.error("Unexpected error: %s", exc, exc_info=True)
        return jsonify({"error": "Internal server error."}), 500


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host="localhost", port=8000, debug=False)
