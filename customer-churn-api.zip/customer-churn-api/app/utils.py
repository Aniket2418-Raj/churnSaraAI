"""
utils.py — Helper functions for the churn prediction API.
"""

import pandas as pd
import numpy as np


# ── Column order must exactly match what the transformer was fitted on ──────
NUMERICAL_COLS = [
    "SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges",
    "tenure_years", "spend_per_month",
]

CATEGORICAL_COLS = [
    "gender", "Partner", "Dependents", "PhoneService", "MultipleLines",
    "InternetService", "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies", "Contract",
    "PaperlessBilling", "PaymentMethod",
]

ALL_FEATURE_COLS = NUMERICAL_COLS + CATEGORICAL_COLS


def customer_json_to_df(customer_dict: dict) -> pd.DataFrame:
    """
    Convert a raw customer dict (from the /predict request body)
    into a single-row DataFrame with the correct columns.

    Also coerces TotalCharges to numeric (handles blank strings).
    """
    df = pd.DataFrame([customer_dict])

    # Keep only the columns the model knows about
    missing = [c for c in ALL_FEATURE_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required fields: {missing}")

    df = df[ALL_FEATURE_COLS]
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    return df


def predict_churn(customer_df: pd.DataFrame, transformer, model) -> dict:
    """
    Apply the preprocessing pipeline and return churn probability + label.
    """
    X_transformed = transformer.transform(customer_df)
    proba = float(model.predict_proba(X_transformed)[0, 1])
    prediction = "Yes" if proba >= 0.5 else "No"
    return {"churn_probability": round(proba, 4), "churn_prediction": prediction}
