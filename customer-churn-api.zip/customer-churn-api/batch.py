"""
batch.py — Overnight batch scoring pipeline.

Usage:
    python batch.py --input test_data/all_customers.csv

Reads each row from the CSV, sends it to the running Flask API, and writes
scored_customers.csv with predictions appended.  Summary statistics are
logged to logs/batch_log.txt.
"""

import argparse
import csv
import json
import logging
import os
import time
from pathlib import Path

import requests

# ── Config ────────────────────────────────────────────────────────────────────
API_URL = "http://localhost:8000/predict"
TIMEOUT = 10  # seconds per request

# ── Output paths ──────────────────────────────────────────────────────────────
OUTPUT_CSV = Path("scored_customers.csv")
LOGS_DIR = Path("logs")
LOG_FILE = LOGS_DIR / "batch_log.txt"

LOGS_DIR.mkdir(exist_ok=True)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# ── Columns used by the model ─────────────────────────────────────────────────
FEATURE_COLS = [
    "gender", "SeniorCitizen", "Partner", "Dependents", "tenure",
    "PhoneService", "MultipleLines", "InternetService", "OnlineSecurity",
    "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV",
    "StreamingMovies", "Contract", "PaperlessBilling", "PaymentMethod",
    "MonthlyCharges", "TotalCharges", "tenure_years", "spend_per_month",
]


def row_to_customer(row: dict) -> dict:
    """Extract only the model feature columns from a CSV row."""
    customer = {}
    for col in FEATURE_COLS:
        val = row.get(col, "")
        # Attempt numeric coercion for numeric-looking values
        try:
            customer[col] = float(val) if "." in str(val) else int(val)
        except (ValueError, TypeError):
            customer[col] = val
    return customer


def score_csv(input_path: str) -> None:
    logger.info("=" * 60)
    logger.info("Batch job started — input: %s", input_path)
    logger.info("=" * 60)

    start_time = time.time()
    total = 0
    failures = 0
    probabilities = []
    results = []

    with open(input_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    logger.info("Loaded %d rows from %s", len(rows), input_path)

    for idx, row in enumerate(rows):
        total += 1
        customer_id = row.get("customerID", f"row_{idx}")
        payload = {"customer": row_to_customer(row)}

        try:
            resp = requests.post(API_URL, json=payload, timeout=TIMEOUT)
            if resp.status_code == 200:
                data = resp.json()
                churn_prob = data.get("churn_probability", None)
                churn_pred = data.get("churn_prediction", None)
                probabilities.append(churn_prob)
                results.append({
                    **row,
                    "churn_probability": churn_prob,
                    "churn_prediction": churn_pred,
                })
            else:
                failures += 1
                logger.warning(
                    "Non-200 response for customerID=%s: HTTP %d — %s",
                    customer_id, resp.status_code, resp.text[:200],
                )
                results.append({**row, "churn_probability": None, "churn_prediction": "ERROR"})

        except requests.exceptions.RequestException as exc:
            failures += 1
            logger.error("Request failed for customerID=%s: %s", customer_id, exc)
            results.append({**row, "churn_probability": None, "churn_prediction": "ERROR"})

    # ── Write output CSV ──────────────────────────────────────────────────────
    if results:
        fieldnames = list(results[0].keys())
        with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)
        logger.info("Scored customers written to %s", OUTPUT_CSV)

    # ── Summary stats ─────────────────────────────────────────────────────────
    elapsed = time.time() - start_time
    successful = total - failures
    avg_prob = sum(probabilities) / len(probabilities) if probabilities else 0.0

    logger.info("-" * 60)
    logger.info("BATCH SUMMARY")
    logger.info("  Total requests   : %d", total)
    logger.info("  Successful       : %d", successful)
    logger.info("  Failed           : %d", failures)
    logger.info("  Avg churn prob   : %.4f", avg_prob)
    logger.info("  Elapsed time     : %.2f seconds", elapsed)
    logger.info("-" * 60)


def main():
    parser = argparse.ArgumentParser(description="Batch churn scoring pipeline")
    parser.add_argument(
        "--input",
        required=True,
        help="Path to input CSV file (e.g. test_data/all_customers.csv)",
    )
    args = parser.parse_args()

    if not os.path.exists(args.input):
        logger.error("Input file not found: %s", args.input)
        raise SystemExit(1)

    score_csv(args.input)


if __name__ == "__main__":
    main()
